library(ggplot2)
library(ggforce)
library(dplyr)
library(stringr)

# 使用readxl包来读取Excel文件
library(readxl)

# 读取Excel文件
keggresult <- read_excel("C:/Users/张圣欣/Desktop/棒棒糖图.xlsx")

# 数据处理，确保Doses列存在
dat <- keggresult %>%
  arrange(Confidence) %>%
  mutate(Description = factor(Description, levels = rev(unique(Description)))) 

# 计算 log10(Confidence)
dat$log_Confidence <- log10(dat$Confidence)

# Wrap description for better readability
dat$Wrapped_Description <- str_wrap(dat$Description, width = 40)

# ——【颜色：类别配色（link 的颜色）】——
# 用柔和马卡龙系；当类别数>8时自动插值扩展
num_categories <- length(unique(dat$category))
base_cols <- c( "#B6E3E3", "#F7E3A1", "#CBE6A3",
                "#BFD7EA", "#FAD4C0", "#D7C7FF")



# ——【颜色：Confidence 渐变（球体填充）】——
# 顶刊风：深洋红 -> 洋红 -> 粉 -> 浅桃 -> 很浅粉 -> 近白
custom_colors <- c(
  "#E65100",  # 核心色 - Deeper, more saturated orange
  "#FF9800",  # 浅橘色 - Lighter orange
  "#FFB74D",  # 更浅的橘色 - Even lighter orange
  "#FFCC80",  # 接近白色的浅橘色 - Pale orange
  "#FFF3E0"   # 近白（低值端） - Almost white with a hint of orange
)


# 调整文本换行的宽度，设置更大的值
dat$Wrapped_Description <- str_wrap(dat$Description, width = 80)  # 增大宽度

# 排序 dat 数据框，按照 Count 从大到小排序
dat <- dat %>%
  arrange(desc(Count)) %>%
  mutate(Wrapped_Description = factor(Wrapped_Description, levels = unique(Wrapped_Description)))  # 按照 Count 排序 Wrapped_Description

# 创建绘图
ggplot(dat) +
  ggforce::geom_link(
    aes(
      x = 0, 
      y = Wrapped_Description,
      xend = Count,  # 使用 Count 作为 x 坐标
      yend = Wrapped_Description,
      color = category,  # 以 category 区分颜色
      size = 2  # 设置 size 值（按你的原写法保留）
    ),
    n = 500,
    show.legend = c(color = TRUE, size = FALSE)  # 只显示颜色图例
  ) +
  geom_point(
    aes(
      x = Count,  # 使用 Count 作为 x 坐标
      y = Wrapped_Description,
      fill = log_Confidence  # 使用 log10(Confidence) 填充颜色
    ),
    color = "black", 
    size = 5,
    shape = 21,
    show.legend = TRUE  # 显示填充图例
  ) +
  # 添加文本标签，标注 No of studies 的数字并调整位置
  geom_text(
    aes(
      x = Count + 2,  # 将文本向右偏移，减少偏移量，使数字离球体更近
      y = Wrapped_Description,
      label = Count  # 在球体后面显示 Count 值
    ),
    size = 4,  # 标签字体大小
    color = "black",  # 标签颜色
    hjust = 0  # 水平对齐方式，确保文本靠右显示
  ) +
  scale_color_manual(
    values = levelcolor,
    name = "Category"
  ) +
  scale_fill_gradientn(
    colors = custom_colors,  # 使用渐变色来显示连续变量
    values = scales::rescale(seq(0, 6, length.out = 100)),
    name = "Log10(Confidence)"
  ) +
  guides(
    alpha = "none",
    size = "none"
  ) +
  theme_bw() +
  theme(
    panel.background = element_rect(fill = NA),
    panel.grid = element_blank(),
    panel.border = element_blank(),
    axis.line = element_line(color = "black", linewidth = 0.75),
    axis.text.y = element_text(
      color = "black", 
      size = 12,
      lineheight = 0.8
    ),
    axis.text.x = element_text(color = "black", size = 12),
    axis.title = element_text(size = 12),
    legend.text = element_text(size = 12),
    legend.title = element_text(size = 12),
    plot.margin = margin(1, 1, 1, 2, "cm")
  ) +
  ylab("") + 
  xlab("No of studies") +
  scale_x_continuous(expand = expansion(mult = c(0, 0.04))) +
  scale_y_discrete(limits = rev)  # 保持反转 y 轴顺序
