# Fig S1
library(ggplot2)
library(tidyr)
library(dplyr)

data <- data.frame(
  Criterion = c("PICO", "Protocol", "Study selection", "Search strategy", "Study selection in duplicate",
                "Data extraction in duplicate", "List of excluded studies", "Description of included studies",
                "Satisfactory RoB assessment", "Sources of funding", "Statistical combination of results",
                "Effect of RoB on meta-analysis", "Account for RoB in interpretation",
                "Explanation for heterogeneity", "Publication bias", "Conflict of interest"),
  Yes = c(           100, 42,   100, 96, 91, 91, 55,  96,   83,  1,   100,  71,  89,  97, 92, 91),
  `Partial yes` = c(0,    58,   0,   4,  9,  9,  45,  4,    17,  99,  0,    29,  11,  3,  8, 9),
  No = c(           0,    0,    0,   0,  0,  0,  0,   0,    0,   0,   0,    0,   0,   0,  0, 0),
  check.names = FALSE  
)

data_long <- pivot_longer(
  data,
  cols = c("Yes", "Partial yes", "No"),
  names_to = "Response",
  values_to = "Count"
)

response_colors <- c(
  "Yes" = "#00C1B2",         
  "Partial yes" = "#F9B233", 
  "No" = "#E94B4B"           
)

ggplot(data_long, aes(x = Count, 
                      y = factor(Criterion, levels = rev(c("PICO", "Protocol", "Study selection", "Search strategy", 
                                                           "Study selection in duplicate", "Data extraction in duplicate", 
                                                           "List of excluded studies", "Description of included studies", 
                                                           "Satisfactory RoB assessment", "Sources of funding", 
                                                           "Statistical combination of results", "Effect of RoB on meta-analysis", 
                                                           "Account for RoB in interpretation", "Explanation for heterogeneity", 
                                                           "Publication bias", "Conflict of interest"))),
                      fill = Response)) +
  geom_bar(stat = "identity") +
  geom_text(aes(label = ifelse(Count == 0, NA, Count)),
            position = position_stack(vjust = 0.5), size = 3) +
  scale_fill_manual(values = response_colors) +
  labs(
    title = "AMSTAR-2 assessment",
    x = NULL, y = NULL,
    caption = "Note: The chart shows how many studies met each AMSTAR-2 criterion ('Yes', 'Partial yes', 'No')."
  ) +
  theme_minimal(base_size = 13) +
  theme(
    legend.position = "top",
    panel.grid.major.y = element_blank(),
    plot.caption = element_text(hjust = 0, size = 9, face = "italic", margin = margin(t = 10))
  )