# ===== 你已有的导入部分（保持不变） =====
# 安装一次即可
# install.packages(c("readxl", "metafor", "metasens", "writexl"))

library(readxl)
library(metafor)
library(metasens)   # tes()
library(writexl)

# 1) 读取 Excel （你已指定 sheet = 1，这里不改）
dat <- read_excel("C:/Users/张圣欣/Desktop/原始数据（非剂量反应关系新） (1).xlsx", sheet = 27)

# 获取 Sheet 名称作为文件名（保持不变，虽然下方未用到也无妨）
sheet1_name <- names(dat)[27]

# ===== 从这里开始：用"进阶版"逻辑替换你原来的分析计算部分 =====

# 安全数值化
numify <- function(x) suppressWarnings(as.numeric(as.character(x)))

# Rosenthal FSN：Stouffer 备选实现（当 metafor::fsn 报错时备用）
rosenthal_fsn_stouffer <- function(yi, sei, alpha=0.05){
  ok <- is.finite(yi) & is.finite(sei) & sei > 0
  if(sum(ok) < 1) return(NA_real_)
  yi_ok  <- yi[ok]
  sei_ok <- sei[ok]
  k <- length(yi_ok)
  zi <- yi_ok / sei_ok
  sum_z <- sum(zi)
  z_crit <- qnorm(1 - alpha/2)
  # 已经不显著，FSN=0
  if (abs(sum_z / sqrt(k)) <= z_crit) return(0)
  fsn_val <- (sum_z / z_crit)^2 - k
  return(max(0, ceiling(fsn_val)))
}

# 自动识别"效应量 + 置信区间"列（兼容 OR/RR/HR 或差值型效应）
detect_effect <- function(df){
  cn <- names(df)
  ratio_cols    <- c("OR","RR","HR")
  all_eff_cols  <- c(ratio_cols,"TE","yi","ES","SMD","g","d","effect","Effect")
  
  eff_col_name <- intersect(all_eff_cols, cn)[1]
  lci_col <- intersect(c("lci","LCI","lower","Lower","lo","loCI","ci.lb"), cn)[1]
  uci_col <- intersect(c("uci","UCI","upper","Upper","hi","hiCI","ci.ub"), cn)[1]
  
  if (is.na(eff_col_name) || is.na(lci_col) || is.na(uci_col)) {
    stop("缺少效应量或区间列（需要 OR/RR/HR/TE/SMD + lci + uci）")
  }
  
  eff <- numify(df[[eff_col_name]])
  lci <- numify(df[[lci_col]])
  uci <- numify(df[[uci_col]])
  keep <- is.finite(eff) & is.finite(lci) & is.finite(uci)
  eff <- eff[keep]; lci <- lci[keep]; uci <- uci[keep]
  if (length(eff) < 2) stop("有效数据不足（<2条）")
  
  is_ratio <- eff_col_name %in% ratio_cols
  list(eff=eff, lci=lci, uci=uci, is_ratio=is_ratio)
}

# 更稳健的随机效应拟合（多种控制参数/优化器尝试）
fit_random <- function(yi, vi, try_hksj=TRUE){
  ctrl_list <- list(
    list(),
    list(stepadj=0.5, maxiter=10000),
    list(optimizer="nlminb"),
    list(optimizer="optim", "opt.method"="BFGS")
  )
  tests <- if (try_hksj) c("knha","t","z") else c("z")
  for (test in tests){
    for (ctrl in ctrl_list){
      fit <- try(rma(yi=yi, vi=vi, method="REML", test=test, control=ctrl), silent=TRUE)
      if (!inherits(fit,"try-error")) return(fit)
    }
    fit_ml <- try(rma(yi=yi, vi=vi, method="ML", test=test), silent=TRUE)
    if (!inherits(fit_ml,"try-error")){
      fit_reml <- try(update(fit_ml, method="REML", test=test), silent=TRUE)
      if (!inherits(fit_reml,"try-error")) return(fit_reml)
    }
  }
  stop("REML方法未能收敛")
}

# 达到"名义显著"的最小新增研究数（默认双侧 alpha=0.05）
min_m_for_nominal_sig <- function(yi, vi, tau2, theta_future=NULL, w_future=NULL, alpha=0.05){
  w <- 1/(vi + tau2)
  W <- sum(w); S <- sum(w*yi)
  zc <- qnorm(1 - alpha/2)
  if (is.null(theta_future)) theta_future <- sum(w*yi)/W
  if (is.null(w_future))     w_future     <- mean(w)
  A <- (w_future*theta_future)
  a <- A^2
  b <- (2*A*S) - (zc^2)*w_future
  c <- S^2 - (zc^2)*W
  if (abs(A) < .Machine$double.eps) return(Inf)
  disc <- b^2 - 4*a*c
  if (disc < 0) return(Inf)
  r1 <- (-b - sqrt(disc)) / (2*a); r2 <- (-b + sqrt(disc)) / (2*a)
  m_needed <- ceiling(max(r1, r2, 0))
  as.integer(m_needed)
}

# 达到 80% 条件把握度的最小新增研究数
min_m_for_CP <- function(yi, vi, tau2, theta_future=NULL, w_future=NULL, power=0.80, alpha=0.05, max_add=2000){
  w <- 1/(vi + tau2)
  W <- sum(w); S <- sum(w*yi)
  zc <- qnorm(1 - alpha/2)
  if (is.null(theta_future)) theta_future <- sum(w*yi)/W
  if (is.null(w_future))     w_future     <- mean(w)
  for (m in 1:max_add){
    Wt <- W + m*w_future
    mu <- (S + m*w_future*theta_future) / sqrt(Wt)
    sd <- sqrt( (m*w_future) / Wt )
    # 双侧检验的条件把握度
    cp <- pnorm(-zc, mean=mu, sd=sd) + (1 - pnorm(zc, mean=mu, sd=sd))
    if (cp >= power) return(m)
  }
  Inf
}

# 单次运行（核心）：输入效应+区间，输出所有统计量
run_meta_once <- function(eff, lci, uci, is_ratio){
  if (is_ratio){
    yi  <- log(eff)
    sei <- (log(uci) - log(lci)) / (2*1.96)
  } else {
    yi  <- eff
    sei <- (uci - lci) / (2*1.96)
  }
  vi <- sei^2
  ok <- is.finite(yi) & is.finite(vi) & vi > 0
  yi <- yi[ok]; vi <- vi[ok]; sei <- sei[ok]
  if (length(yi) < 2) stop("有效研究条目不足（<2条）")
  
  fit <- fit_random(yi, vi, try_hksj = TRUE)
  
  b   <- as.numeric(coef(fit))
  se  <- sqrt(diag(vcov(fit)))[1]
  
  # 使用fit对象的p值（基于相应的检验方法）
  p   <- fit$pval
  
  tau2 <- if(!is.null(fit$tau2)) fit$tau2 else NA_real_
  I2   <- if(!is.null(fit$I2)) fit$I2 else {
    k <- length(yi); df <- k - 1
    QE <- if(!is.null(fit$QE)) fit$QE else NA_real_
    if (is.finite(QE) && df>0) max(0, (QE - df)/QE)*100 else NA_real_
  }
  
  # 关键修改：使用fit对象的置信区间（基于相应的分布）
  if (is_ratio){
    TE <- exp(b)
    lo <- exp(fit$ci.lb)  # 使用fit对象的置信下限
    hi <- exp(fit$ci.ub)  # 使用fit对象的置信上限
  } else {
    TE <- b
    lo <- fit$ci.lb       # 使用fit对象的置信下限
    hi <- fit$ci.ub       # 使用fit对象的置信上限
  }
  
  egger_p <- tryCatch({
    regtest(yi, sei, model="lm")$pval
  }, error=function(e) NA_real_)
  
  tes_p <- tryCatch({
    tes(fit, H0=0, alternative="two.sided", alpha=.05)$pval
  }, error=function(e) NA_real_)
  
  rosenberg  <- NA_real_
  rosenthal  <- NA_real_
  m_nom_pool <- NA_integer_; m_nom_max <- NA_integer_
  m_cp80_pool<- NA_integer_; m_cp80_max<- NA_integer_
  notes <- ""
  
  w      <- 1/(vi + ifelse(is.finite(tau2), tau2, 0))
  wbar   <- mean(w)
  theta_pool <- b
  theta_max  <- yi[ which.max(w) ]
  
  if (isTRUE(p < 0.05)) {
    rosenberg <- tryCatch({
      as.numeric(fsn(yi=yi, vi=vi, type="Rosenberg")$fsnum)
    }, error=function(e) NA_real_)
    rosenthal <- tryCatch({
      as.numeric(fsn(yi=yi, vi=vi, type="Rosenthal")$fsnum)
    }, error=function(e) {
      rosenthal_fsn_stouffer(yi, sqrt(vi))
    })
  } else {
    if (!is.finite(tau2)) tau2 <- 0
    m_nom_pool  <- min_m_for_nominal_sig(yi, vi, tau2, theta_future=theta_pool, w_future=wbar, alpha=0.05)
    m_nom_max   <- min_m_for_nominal_sig(yi, vi, tau2, theta_future=theta_max,  w_future=wbar, alpha=0.05)
    m_cp80_pool <- min_m_for_CP(yi, vi, tau2, theta_future=theta_pool, w_future=wbar, power=0.80, alpha=0.05)
    m_cp80_max  <- min_m_for_CP(yi, vi, tau2, theta_future=theta_max,  w_future=wbar, power=0.80, alpha=0.05)
    if (is.infinite(m_nom_pool) && is.infinite(m_cp80_pool)) {
      notes <- "在默认情景下，即使增加大量研究也难以达成名义显著/80%把握度；请检查θ*与权重设定"
    }
  }
  
  list(
    k                = length(yi),
    TE_random        = TE,
    lower_random     = lo,
    upper_random     = hi,
    pval_random      = p,
    tau2             = tau2,
    I2               = I2,
    Egger_p          = egger_p,
    TES_p            = tes_p,
    FSN_Rosenberg    = rosenberg,
    FSN_Rosenthal    = rosenthal,
    m_nominal_theta_pool = m_nom_pool,
    m_nominal_theta_max  = m_nom_max,
    m_CP80_theta_pool    = m_cp80_pool,
    m_CP80_theta_max     = m_cp80_max,
    notes            = notes
  )
}

# —— 用进阶版流程跑一次 —— #
det <- detect_effect(dat)
res <- run_meta_once(det$eff, det$lci, det$uci, det$is_ratio)

# 整理成数据框（write_xlsx 需要 data.frame）
result_df <- data.frame(
  k_studies              = res$k,
  pooled_effect          = round(res$TE_random, 3),
  lower_ci               = round(res$lower_random, 3),
  upper_ci               = round(res$upper_random, 3),
  p_value                = signif(res$pval_random, 3),
  tau2                   = round(res$tau2, 4),
  I2                     = round(res$I2, 1),
  Egger_p                = signif(res$Egger_p, 3),
  TES_p                  = signif(res$TES_p, 3),
  FSN_Rosenberg          = res$FSN_Rosenberg,
  FSN_Rosenthal          = res$FSN_Rosenthal,
  m_nominal_theta_pool   = res$m_nominal_theta_pool,
  m_nominal_theta_max    = res$m_nominal_theta_max,
  m_CP80_theta_pool      = res$m_CP80_theta_pool,
  m_CP80_theta_max       = res$m_CP80_theta_max,
  notes                  = res$notes,
  stringsAsFactors = FALSE
)

# 同时在控制台打印（可选）
print(result_df)

# ===== 你已有的导出部分（保持不变；按你的路径写出） =====
folder_path <- "C:/Users/张圣欣/Desktop/新建文件夹 (9)"  # 你的输出文件夹
# 你也可以手动改名避免覆盖，比如加时间戳：
# timestamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
# output_file <- file.path(folder_path, paste0("meta_analysis_results_", timestamp, ".xlsx"))

output_file <- file.path(folder_path, "meta_analysis_nondose_sheet 27.xlsx")  # 你原来的命名

# 写 Excel（会新建或覆盖同名文件）
write_xlsx(result_df, output_file)
cat("结果已成功保存到文件夹：", output_file, "\n")
